package com.aurionpro.controller;

import com.aurionpro.service.DashboardService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
@CrossOrigin(origins = "*")
public class DashboardController {

    private final DashboardService dashboardService;

    public DashboardController(DashboardService dashboardService) {
        this.dashboardService = dashboardService;
    }

    /** 👤 USER DASHBOARD — personal stats (requires authentication) */
    @GetMapping("/user")
    public ResponseEntity<Map<String, Object>> getUserDashboard(Authentication auth) {
        if (auth == null || auth.getName() == null) {
            return ResponseEntity.status(401).body(Map.of("error", "Unauthorized"));
        }

        Map<String, Object> stats = dashboardService.userStats(auth.getName());
        return ResponseEntity.ok(stats);
    }

    /** 👑 ADMIN DASHBOARD — global analytics */
    @GetMapping("/admin")
    public ResponseEntity<Map<String, Object>> getAdminDashboard() {
        Map<String, Object> stats = dashboardService.adminStats();
        return ResponseEntity.ok(stats);
    }
}
