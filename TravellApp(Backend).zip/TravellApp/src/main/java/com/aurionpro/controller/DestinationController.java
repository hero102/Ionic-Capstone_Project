package com.aurionpro.controller;

import com.aurionpro.entity.Destination;
import com.aurionpro.service.DestinationService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@RestController
@RequestMapping("/api/destinations")
@CrossOrigin(origins = "*")
public class DestinationController {

    private final DestinationService destinationService;

    @Value("${upload.dir:uploads}")
    private String uploadDir;

    @Value("${server.base.url:http://localhost:8080}")
    private String serverBaseUrl;

    public DestinationController(DestinationService destinationService) {
        this.destinationService = destinationService;
    }

    // ✅ Get all destinations
    @GetMapping
    public List<Destination> getAll() {
        return destinationService.findAll();
    }

    // ✅ Get one destination by ID
    @GetMapping("/{id}")
    public ResponseEntity<Destination> getById(@PathVariable Long id) {
        return destinationService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // ✅ Create new destination (JSON only)
    @PostMapping
    public Destination create(@RequestBody Destination d) {
        return destinationService.save(d);
    }

    // ✅ Create new destination with file upload
    @PostMapping("/upload")
    public ResponseEntity<Destination> createWithFile(
            @RequestPart("name") String name,
            @RequestPart("category") String category,
            @RequestPart(value = "description", required = false) String description,
            @RequestPart(value = "file", required = false) MultipartFile file
    ) throws IOException {

        Destination dest = new Destination();
        dest.setName(name);
        dest.setCategory(category);
        dest.setDescription(description);

        if (file != null && !file.isEmpty()) {
            // 🖼 Save file
            String filename = System.currentTimeMillis() + "_" + file.getOriginalFilename();
            Path filePath = Paths.get(uploadDir, filename);
            Files.createDirectories(filePath.getParent());
            Files.write(filePath, file.getBytes());

            // 🌐 Set full URL
            String fileUrl = serverBaseUrl + "/uploads/" + filename;
            dest.setImageUrl(fileUrl);

            System.out.println("✅ Created image: " + fileUrl);
        }

        Destination saved = destinationService.save(dest);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    // ✅ Update existing destination with file upload
    @PutMapping("/upload/{id}")
    public ResponseEntity<Destination> updateWithFile(
            @PathVariable Long id,
            @RequestPart("name") String name,
            @RequestPart("category") String category,
            @RequestPart(value = "description", required = false) String description,
            @RequestPart(value = "file", required = false) MultipartFile file
    ) throws IOException {

        Destination existing = destinationService.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Destination not found"));

        existing.setName(name);
        existing.setCategory(category);
        existing.setDescription(description);

        if (file != null && !file.isEmpty()) {
            // 🧹 Delete old file first
            destinationService.deleteFileIfExists(existing.getImageUrl());

            // 🖼 Save new file
            String filename = System.currentTimeMillis() + "_" + file.getOriginalFilename();
            Path filePath = Paths.get(uploadDir, filename);
            Files.createDirectories(filePath.getParent());
            Files.write(filePath, file.getBytes());

            String fileUrl = serverBaseUrl + "/uploads/" + filename;
            existing.setImageUrl(fileUrl);

            System.out.println("✅ Updated image: " + fileUrl);
        }

        Destination updated = destinationService.save(existing);
        return ResponseEntity.ok(updated);
    }

    // ✅ Update destination (text-only)
    @PutMapping("/{id}")
    public ResponseEntity<Destination> update(@PathVariable Long id, @RequestBody Destination updated) {
        Destination saved = destinationService.update(id, updated);
        return ResponseEntity.ok(saved);
    }

 // ✅ Get all unique categories (no duplicates)
    @GetMapping("/categories")
    public ResponseEntity<List<String>> getUniqueCategories() {
        List<String> uniqueCategories = destinationService.getUniqueCategories();
        return ResponseEntity.ok(uniqueCategories);
    }

    // ✅ Safe delete destination (handles foreign key conflicts)
    @DeleteMapping("/{id}")
    public ResponseEntity<?> delete(@PathVariable Long id) {
        try {
            destinationService.delete(id);
            return ResponseEntity.noContent().build();
        } catch (ResponseStatusException e) {
            // Handle 404 / 409 from service
            return ResponseEntity.status(e.getStatusCode())
                    .body(e.getReason());
        } catch (Exception e) {
            // Catch-all fallback
            System.err.println("❌ Delete failed: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("An unexpected error occurred while deleting the destination.");
        }
    }
}
