package com.aurionpro.controller;

import com.aurionpro.service.MaintenanceService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/settings")
@CrossOrigin(origins = "*")
public class MaintenanceController {

    private final MaintenanceService service;

    public MaintenanceController(MaintenanceService service) {
        this.service = service;
    }

    /** ✅ Get current maintenance mode */
    @GetMapping("/maintenance")
    public ResponseEntity<Boolean> getMaintenance() {
        return ResponseEntity.ok(service.isActive());
    }

    /** ✅ Admin: enable or disable maintenance mode (accept JSON body) */
    @PostMapping("/maintenance")
    public ResponseEntity<Void> updateMaintenance(@RequestBody Map<String, Boolean> body) {
        boolean active = body.getOrDefault("active", false);
        System.out.println("🌐 Maintenance updated → " + active);
        service.setActive(active);
        return ResponseEntity.ok().build();
    }
}
