package com.aurionpro.controller;

import com.aurionpro.entity.Trip;
import com.aurionpro.entity.User;
import com.aurionpro.repository.DestinationRepository;
import com.aurionpro.service.TripService;
import com.aurionpro.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/trips")
@CrossOrigin(origins = "*")
public class TripController {

    private final TripService tripService;
    private final UserService userService;
    private final DestinationRepository destinationRepository;

    public TripController(
            TripService tripService,
            UserService userService,
            DestinationRepository destinationRepository
    ) {
        this.tripService = tripService;
        this.userService = userService;
        this.destinationRepository = destinationRepository;
    }

    // 🌍 PUBLIC FEED — only approved trips (visible to everyone)
    @GetMapping("/feed")
    public ResponseEntity<List<Trip>> getApprovedFeed() {
        List<Trip> approvedTrips = tripService.findApprovedTrips();
        return ResponseEntity.ok(approvedTrips);
    }

    // 👤 USER — Get my trips (drafts + pending + published)
    @GetMapping("/me")
    public ResponseEntity<List<Trip>> getMyTrips(Authentication auth) {
        User user = userService.findByEmail(auth.getName());
        return ResponseEntity.ok(tripService.getByUser(user));
    }

    // ➕ USER — Create a new trip (can be draft or send-for-approval)
    @PostMapping
    public ResponseEntity<Trip> createTrip(@RequestBody Trip trip, Authentication auth) {
        User user = userService.findByEmail(auth.getName());
        trip.setUser(user);

        // 🧠 Ensure logical consistency
        if (trip.getDraft() && trip.getApproved()) {
            trip.setApproved(false); // drafts cannot be approved directly
        }

        Trip savedTrip = tripService.save(trip);
        return ResponseEntity.ok(savedTrip);
    }

    // ✏️ USER — Update an existing trip (draft → pending flow)
    @PutMapping("/{id}")
    public ResponseEntity<Trip> updateTrip(
            @PathVariable Long id,
            @RequestBody Trip trip,
            Authentication auth
    ) {
        User user = userService.findByEmail(auth.getName());

        // 🧠 Ensure logical consistency again
        if (trip.getDraft() && trip.getApproved()) {
            trip.setApproved(false);
        }

        Trip updatedTrip = tripService.update(id, trip, user);
        return ResponseEntity.ok(updatedTrip);
    }

    // ❌ USER — Delete a trip (and delete orphan destination if unused)
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTrip(@PathVariable Long id, Authentication auth) {
        User user = userService.findByEmail(auth.getName());
        Trip deletedTrip = tripService.delete(id, user);

        // 🧹 Cleanup: Delete destination if no other trips reference it
        if (deletedTrip.getDestination() != null) {
            Long destId = deletedTrip.getDestination().getId();
            boolean stillUsed = tripService.existsByDestinationId(destId);
            if (!stillUsed) {
                destinationRepository.deleteById(destId);
            }
        }

        return ResponseEntity.noContent().build();
    }

    // 👮 ADMIN ROUTES ===============================

    // ✅ Admin — Get all NON-DRAFT trips (pending + approved + featured)
    @GetMapping("/admin/all")
    public ResponseEntity<List<Trip>> getAllTripsForAdmin() {
        // Filter only non-draft trips for admin dashboard
        List<Trip> allTrips = tripService.findAll();
        List<Trip> visibleTrips = allTrips.stream()
                .filter(t -> !t.getDraft())
                .toList();
        return ResponseEntity.ok(visibleTrips);
    }

    // 📊 Admin Dashboard Statistics
    @GetMapping("/admin/stats")
    public ResponseEntity<Map<String, Long>> getAdminStats() {
        return ResponseEntity.ok(tripService.getAdminStats());
    }

    // ✅ Admin — Approve a trip
    @PostMapping("/admin/{id}/approve")
    public ResponseEntity<Trip> approveTrip(@PathVariable Long id) {
        Trip approvedTrip = tripService.approve(id);
        return ResponseEntity.ok(approvedTrip);
    }

    // ✅ Admin — Feature or unfeature a trip
    @PostMapping("/admin/{id}/feature")
    public ResponseEntity<Trip> featureTrip(
            @PathVariable Long id,
            @RequestParam boolean featured
    ) {
        Trip updatedTrip = tripService.setFeatured(id, featured);
        return ResponseEntity.ok(updatedTrip);
    }
}
