package com.aurionpro.controller;

import com.aurionpro.dto.ProfileUpdateRequest;
import com.aurionpro.entity.User;
import com.aurionpro.repository.UserRepository;
import com.aurionpro.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/user")
@CrossOrigin(origins = "*")
public class ProfileController {

    private final UserRepository userRepository;
    private final UserService userService;

    public ProfileController(UserRepository userRepository, UserService userService) {
        this.userRepository = userRepository;
        this.userService = userService;
    }

    // ✅ Fetch current user profile
    @GetMapping("/me")
    public ResponseEntity<?> getProfile(Authentication auth) {
        if (auth == null || auth.getName() == null) {
            return ResponseEntity.status(401).body("Unauthorized");
        }

        User user = userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        // 🚀 Optional: hide password before sending back
        user.setPassword(null);
        return ResponseEntity.ok(user);
    }

    // ✅ Update user profile (name, location, image)
    @PutMapping("/updateProfile")
    public ResponseEntity<?> updateProfile(
            Authentication auth,
            @RequestBody ProfileUpdateRequest req
    ) {
        if (auth == null || auth.getName() == null) {
            return ResponseEntity.status(401).body("Unauthorized");
        }

        User user = userRepository.findByEmail(auth.getName())
                .orElseThrow(() -> new RuntimeException("User not found"));

        if (req.getName() != null && !req.getName().isBlank()) {
            user.setName(req.getName().trim());
        }
        if (req.getLocation() != null && !req.getLocation().isBlank()) {
            user.setLocation(req.getLocation().trim());
        }
        if (req.getProfileImage() != null && !req.getProfileImage().isBlank()) {
            user.setProfileImage(req.getProfileImage().trim());
        }

        userRepository.save(user);

        user.setPassword(null);
        return ResponseEntity.ok(user);
    }
}
