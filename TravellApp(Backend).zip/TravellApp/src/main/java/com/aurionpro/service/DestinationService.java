package com.aurionpro.service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import com.aurionpro.entity.Destination;
import com.aurionpro.repository.DestinationRepository;
import com.aurionpro.repository.TripRepository;

@Service
public class DestinationService {

    private final DestinationRepository destinationRepository;
    private final TripRepository tripRepository;

    public DestinationService(DestinationRepository destinationRepository, TripRepository tripRepository) {
        this.destinationRepository = destinationRepository;
        this.tripRepository = tripRepository;
    }

    // ✅ Get all destinations
    public List<Destination> findAll() {
        return destinationRepository.findAll();
    }

    // ✅ Get one destination by ID
    public Optional<Destination> findById(Long id) {
        return destinationRepository.findById(id);
    }

    // ✅ Get all unique categories (for Admin panel)
    public List<String> getUniqueCategories() {
        return destinationRepository.findAll().stream()
                .map(Destination::getCategory)
                .filter(c -> c != null && !c.isBlank())
                .map(String::trim)
                .map(String::toLowerCase)
                .distinct()
                .sorted()
                .collect(Collectors.toList());
    }

    // ✅ Create or Save destination
    public Destination save(Destination d) {
        if (d.getName() != null) d.setName(d.getName().trim());
        if (d.getCategory() != null) d.setCategory(d.getCategory().trim().toLowerCase());
        return destinationRepository.save(d);
    }

    // ✅ Delete destination safely (check if trips exist first)
    @Transactional
    public void delete(Long id) {
        Destination dest = destinationRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Destination not found"));

        long linkedTrips = tripRepository.countByDestinationId(id);

        if (linkedTrips > 0) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Cannot delete destination because " + linkedTrips + " trip(s) are linked to it."
            );
        }

        try {
            deleteFileIfExists(dest.getImageUrl());
            destinationRepository.delete(dest);
        } catch (DataIntegrityViolationException e) {
            throw new ResponseStatusException(
                    HttpStatus.CONFLICT,
                    "Cannot delete destination because it is referenced by existing trips."
            );
        } catch (Exception e) {
            throw new ResponseStatusException(HttpStatus.INTERNAL_SERVER_ERROR, "Failed to delete destination.");
        }
    }

    // ✅ Safe partial update
    public Destination update(Long id, Destination updated) {
        Destination existing = destinationRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Destination not found"));

        if (updated.getName() != null && !updated.getName().isBlank()) {
            existing.setName(updated.getName().trim());
        }
        if (updated.getCategory() != null && !updated.getCategory().isBlank()) {
            existing.setCategory(updated.getCategory().trim().toLowerCase());
        }
        if (updated.getDescription() != null && !updated.getDescription().isBlank()) {
            existing.setDescription(updated.getDescription().trim());
        }
        if (updated.getImageUrl() != null && !updated.getImageUrl().isBlank()) {
            existing.setImageUrl(updated.getImageUrl().trim());
        }
        if (updated.getRating() >= 0) {
            existing.setRating(updated.getRating());
        }

        return destinationRepository.save(existing);
    }

    // ✅ Utility: safely delete old image file
    public void deleteFileIfExists(String imageUrl) {
        if (imageUrl == null || !imageUrl.contains("/uploads/")) return;

        try {
            String filename = imageUrl.substring(imageUrl.lastIndexOf("/uploads/") + 9);
            Path filePath = Paths.get("uploads", filename);
            if (Files.exists(filePath)) {
                Files.delete(filePath);
                System.out.println("🗑️ Deleted old image: " + filePath.toAbsolutePath());
            } else {
                System.out.println("⚠️ File not found, skipping delete: " + filePath.toAbsolutePath());
            }
        } catch (Exception e) {
            System.err.println("⚠️ Failed to delete image: " + e.getMessage());
        }
    }
}
