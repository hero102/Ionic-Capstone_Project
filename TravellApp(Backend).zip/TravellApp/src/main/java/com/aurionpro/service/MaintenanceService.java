package com.aurionpro.service;

import com.aurionpro.entity.MaintenanceStatus;
import com.aurionpro.repository.MaintenanceRepository;
import org.springframework.stereotype.Service;
import jakarta.annotation.PostConstruct;
import java.util.List;

@Service
public class MaintenanceService {

    private final MaintenanceRepository repo;

    public MaintenanceService(MaintenanceRepository repo) {
        this.repo = repo;
    }

    @PostConstruct
    public void init() {
        // Ensure a default record exists
        if (repo.count() == 0) {
            repo.save(new MaintenanceStatus(false));
        }
    }

    public boolean isActive() {
        List<MaintenanceStatus> all = repo.findAll();
        return !all.isEmpty() && all.get(0).isActive();
    }

    public void setActive(boolean active) {
        List<MaintenanceStatus> all = repo.findAll();
        MaintenanceStatus status = all.isEmpty() ? new MaintenanceStatus() : all.get(0);
        status.setActive(active);
        repo.save(status);
    }
}
