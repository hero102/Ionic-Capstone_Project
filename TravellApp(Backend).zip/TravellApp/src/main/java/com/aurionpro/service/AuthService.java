package com.aurionpro.service;

import com.aurionpro.dto.AuthRequest;
import com.aurionpro.dto.AuthResponse;
import com.aurionpro.dto.RegisterRequest;
import com.aurionpro.entity.Role;
import com.aurionpro.entity.User;
import com.aurionpro.repository.UserRepository;
import com.aurionpro.util.JwtUtils;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.stream.Collectors;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtils jwtUtils;

    public AuthService(UserRepository userRepository, PasswordEncoder passwordEncoder, JwtUtils jwtUtils) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtils = jwtUtils;
    }

    public AuthResponse register(RegisterRequest req) {
        if (userRepository.findByEmail(req.getEmail()).isPresent()) {
            throw new RuntimeException("Email already in use");
        }

        User u = new User();
        u.setName(req.getName());
        u.setEmail(req.getEmail());
        u.setPassword(passwordEncoder.encode(req.getPassword()));
        u.setRoles(Set.of(Role.ROLE_USER));

        userRepository.save(u);
        String token = jwtUtils.generateToken(u.getEmail());

        // ✅ Return AuthResponse including ID
        return new AuthResponse(
            u.getId(), // 👈 added
            token,
            u.getEmail(),
            u.getName(),
            u.getRoles().stream().map(Enum::name).collect(Collectors.toSet())
        );
    }

    public AuthResponse login(AuthRequest req) {
        User u = userRepository.findByEmail(req.getEmail())
            .orElseThrow(() -> new RuntimeException("Invalid credentials"));

        if (!passwordEncoder.matches(req.getPassword(), u.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        String token = jwtUtils.generateToken(u.getEmail());

        // ✅ Include ID in login response
        return new AuthResponse(
            u.getId(), // 👈 added
            token,
            u.getEmail(),
            u.getName(),
            u.getRoles().stream().map(Enum::name).collect(Collectors.toSet())
        );
    }
}
