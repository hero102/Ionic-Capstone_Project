package com.aurionpro.service;

import com.aurionpro.entity.Trip;
import com.aurionpro.entity.User;
import com.aurionpro.repository.TripRepository;
import com.aurionpro.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class DashboardService {

    private final UserRepository userRepository;
    private final TripRepository tripRepository;

    public DashboardService(UserRepository userRepository, TripRepository tripRepository) {
        this.userRepository = userRepository;
        this.tripRepository = tripRepository;
    }

    // 👑 ===============================
    // ADMIN DASHBOARD STATS
    // ===============================
    public Map<String, Object> adminStats() {
        Map<String, Object> stats = new HashMap<>();

        long totalUsers = userRepository.count();
        long totalTrips = tripRepository.countAllTrips();
        long approvedTrips = tripRepository.countByApprovedTrue();
        long pendingTrips = tripRepository.countPendingTrips();
        long featuredTrips = tripRepository.countByFeaturedTrue();

        stats.put("totalUsers", totalUsers);
        stats.put("totalTrips", totalTrips);
        stats.put("approvedTrips", approvedTrips);
        stats.put("pendingTrips", pendingTrips);
        stats.put("featuredTrips", featuredTrips);

        // 📊 Trips per category (approved only)
        List<Trip> approvedList = tripRepository.findByApprovedTrueOrderByCreatedAtDesc();
        Map<String, Long> tripsPerCategory = approvedList.stream()
                .filter(t -> t.getDestination() != null && t.getDestination().getCategory() != null)
                .collect(Collectors.groupingBy(
                        t -> t.getDestination().getCategory().toLowerCase(),
                        TreeMap::new,
                        Collectors.counting()
                ));

        stats.put("tripsPerCategory", tripsPerCategory);
        return stats;
    }

    // 👤 ===============================
    // USER DASHBOARD STATS
    // ===============================
    public Map<String, Object> userStats(String email) {
        Map<String, Object> stats = new HashMap<>();

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found"));

        List<Trip> userTrips = tripRepository.findByUser(user);
        long totalTrips = userTrips.size();

        // ✅ Null-safe Boolean handling (fixes your compile error)
        long approvedTrips = userTrips.stream()
                .filter(t -> Boolean.TRUE.equals(t.getApproved()))
                .count();

        long featuredTrips = userTrips.stream()
                .filter(t -> Boolean.TRUE.equals(t.getFeatured()))
                .count();

        long draftTrips = userTrips.stream()
                .filter(t -> Boolean.TRUE.equals(t.getDraft()))
                .count();

        stats.put("totalTrips", totalTrips);
        stats.put("approvedTrips", approvedTrips);
        stats.put("draftTrips", draftTrips);
        stats.put("featuredTrips", featuredTrips);

        // 🗂 Trips per category
        Map<String, Long> tripsPerCategory = userTrips.stream()
                .filter(t -> t.getDestination() != null && t.getDestination().getCategory() != null)
                .collect(Collectors.groupingBy(
                        t -> t.getDestination().getCategory().toLowerCase(),
                        TreeMap::new,
                        Collectors.counting()
                ));

        stats.put("tripsPerCategory", tripsPerCategory);
        return stats;
    }
}
