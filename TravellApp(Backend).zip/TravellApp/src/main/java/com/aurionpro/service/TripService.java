package com.aurionpro.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aurionpro.entity.Destination;
import com.aurionpro.entity.Trip;
import com.aurionpro.entity.User;
import com.aurionpro.repository.DestinationRepository;
import com.aurionpro.repository.TripRepository;

@Service
@Transactional
public class TripService {

    private final TripRepository tripRepo;
    private final DestinationRepository destRepo;

    public TripService(TripRepository tripRepo, DestinationRepository destRepo) {
        this.tripRepo = tripRepo;
        this.destRepo = destRepo;
    }

    // ========================================================
    // 🧭 Save or Update Destination (Auto-sync with Trip)
    // ========================================================
    private Destination saveOrUpdateDestination(Destination incoming, Trip trip) {
        if (incoming == null || incoming.getName() == null || incoming.getName().isBlank()) {
            throw new RuntimeException("Destination name is required");
        }

        Destination dest = destRepo.findByNameIgnoreCase(incoming.getName().trim())
                .orElseGet(() -> new Destination(incoming.getName().trim()));

        String category = (incoming.getCategory() != null && !incoming.getCategory().isBlank())
                ? incoming.getCategory().trim().toLowerCase()
                : "uncategorized";
        dest.setCategory(category);

        if (trip.getCaption() != null && !trip.getCaption().isBlank()) {
            dest.setDescription(trip.getCaption().trim());
        }

        if (trip.getImageUrls() != null && !trip.getImageUrls().isEmpty()) {
            dest.setImageUrl(trip.getImageUrls().get(0));
        }

        if (trip.getRating() >= 0) {
            dest.setRating(trip.getRating());
        }

        return destRepo.saveAndFlush(dest);
    }

    // ========================================================
    // ➕ Create or Update Trip (User)
    // ========================================================
    public Trip save(Trip trip) {
        if (trip.getDestination() != null) {
            Destination managedDest = saveOrUpdateDestination(trip.getDestination(), trip);
            trip.setDestination(managedDest);
        }

        if (trip.getRating() < 0) trip.setRating(0);

        // ✅ Respect the frontend draft/approval flags
        if (trip.getDraft() && trip.getApproved()) {
            // invalid state - a draft can't be approved
            trip.setApproved(false);
        }

        return tripRepo.saveAndFlush(trip);
    }

    // ========================================================
    // 🌍 Only Approved Trips for Public Feed
    // ========================================================
    public List<Trip> findApprovedTrips() {
        return tripRepo.findByApprovedTrueOrderByIdDesc();
    }

    // ========================================================
    // ✏️ Update Trip (User)
    // ========================================================
    public Trip update(Long id, Trip updated, User user) {
        Trip existing = tripRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Trip not found"));

        if (!existing.getUser().getId().equals(user.getId())) {
            throw new RuntimeException("Not authorized to update this trip");
        }

        existing.setTitle(updated.getTitle());
        existing.setCaption(updated.getCaption());
        existing.setStartDate(updated.getStartDate());
        existing.setEndDate(updated.getEndDate());
        existing.setImageUrls(updated.getImageUrls());
        existing.setRating(updated.getRating());

        // ✅ Keep correct states
        existing.setDraft(updated.getDraft());
        existing.setApproved(updated.getApproved());

        if (updated.getDestination() != null) {
            Destination managedDest = saveOrUpdateDestination(updated.getDestination(), updated);
            existing.setDestination(managedDest);
        }

        return tripRepo.saveAndFlush(existing);
    }

    // ========================================================
    // 📦 Fetch / CRUD Operations
    // ========================================================
    public Optional<Trip> findById(Long id) {
        return tripRepo.findById(id);
    }

    public List<Trip> getByUser(User user) {
        return tripRepo.findByUser(user);
    }

    public List<Trip> findAll() {
        return tripRepo.findAll();
    }

    // ========================================================
    // 🧾 Admin Actions
    // ========================================================
    public Trip approve(Long id) {
        Trip trip = tripRepo.findById(id).orElseThrow(() -> new RuntimeException("Trip not found"));
        trip.setDraft(false);
        trip.setApproved(true);
        return tripRepo.saveAndFlush(trip);
    }

    public Trip setFeatured(Long id, boolean featured) {
        Trip trip = tripRepo.findById(id).orElseThrow(() -> new RuntimeException("Trip not found"));
        trip.setFeatured(featured);
        return tripRepo.saveAndFlush(trip);
    }

    // ========================================================
    // 🗑️ Delete Trip
    // ========================================================
    public Trip delete(Long id, User user) {
        Trip trip = tripRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Trip not found"));

        if (!trip.getUser().getId().equals(user.getId())) {
            throw new RuntimeException("Not authorized to delete this trip");
        }

        tripRepo.delete(trip);
        return trip;
    }

    // ========================================================
    // 📊 Admin Dashboard Stats
    // ========================================================
    public Map<String, Long> getAdminStats() {
        Map<String, Long> stats = new HashMap<>();
        stats.put("total", tripRepo.countAllTrips());
        stats.put("approved", tripRepo.countByApprovedTrue());
        stats.put("pending", tripRepo.countPendingTrips());
        stats.put("featured", tripRepo.countByFeaturedTrue());
        return stats;
    }

    public boolean existsByDestinationId(Long destId) {
        return tripRepo.existsByDestination_Id(destId);
    }
}
