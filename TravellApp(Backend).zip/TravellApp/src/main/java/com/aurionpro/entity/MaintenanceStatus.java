package com.aurionpro.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "maintenance_status")
public class MaintenanceStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private boolean active = false;

    public MaintenanceStatus() {}

    public MaintenanceStatus(boolean active) {
        this.active = active;
    }

    public Long getId() {
        return id;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }
}
