package com.aurionpro.dto;

import jakarta.validation.constraints.Size;

public class ProfileUpdateRequest {

    @Size(max = 50, message = "Name must not exceed 50 characters")
    private String name;

    @Size(max = 100, message = "Location must not exceed 100 characters")
    private String location;

    @Size(max = 255, message = "Profile image URL is too long")
    private String profileImage;

    // 🧩 Default constructor (required for JSON binding)
    public ProfileUpdateRequest() {}

    // 🧩 All-args constructor (optional convenience)
    public ProfileUpdateRequest(String name, String location, String profileImage) {
        this.name = name;
        this.location = location;
        this.profileImage = profileImage;
    }

    // ✅ Safe getters/setters
    public String getName() {
        return name != null ? name.trim() : null;
    }

    public void setName(String name) {
        this.name = (name != null ? name.trim() : null);
    }

    public String getLocation() {
        return location != null ? location.trim() : null;
    }

    public void setLocation(String location) {
        this.location = (location != null ? location.trim() : null);
    }

    public String getProfileImage() {
        return profileImage != null ? profileImage.trim() : null;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = (profileImage != null ? profileImage.trim() : null);
    }
}
