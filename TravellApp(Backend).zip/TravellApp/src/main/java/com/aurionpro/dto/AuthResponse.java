package com.aurionpro.dto;

import java.util.Set;

public class AuthResponse {
    private Long id;              // ✅ Add this line
    private String token;
    private String email;
    private String name;
    private Set<String> roles;

    public AuthResponse() {}

    public AuthResponse(Long id, String token, String email, String name, Set<String> roles) {
        this.id = id;
        this.token = token;
        this.email = email;
        this.name = name;
        this.roles = roles;
    }

    // ✅ Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Set<String> getRoles() { return roles; }
    public void setRoles(Set<String> roles) { this.roles = roles; }
}
