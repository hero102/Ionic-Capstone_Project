package com.aurionpro.repository;

import com.aurionpro.entity.MaintenanceStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MaintenanceRepository extends JpaRepository<MaintenanceStatus, Long> {}
