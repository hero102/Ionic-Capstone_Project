package com.aurionpro.repository;

import com.aurionpro.entity.Trip;
import com.aurionpro.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface TripRepository extends JpaRepository<Trip, Long> {

    // 🌍 Public feed: Only approved trips, newest first
    List<Trip> findByApprovedTrueOrderByCreatedAtDesc();

    // 👤 Trips for a specific user
    List<Trip> findByUser(User user);

    // 👤 Filter user trips by draft status
    List<Trip> findByUserAndDraft(User user, boolean draft);
    
    long countByDestinationId(Long destinationId);


    // 🧩 Check if any trip still uses a destination
    boolean existsByDestination_Id(Long destinationId);

    // 📊 Dashboard Stats Queries
    @Query("SELECT COUNT(t) FROM Trip t")
    long countAllTrips();

    long countByApprovedTrue();

    @Query("SELECT COUNT(t) FROM Trip t WHERE t.approved = false")
    long countPendingTrips();

    long countByFeaturedTrue();

    // 🔍 Custom search by keyword in title or destination name
    @Query("""
           SELECT t FROM Trip t 
           WHERE LOWER(t.title) LIKE LOWER(CONCAT('%', :keyword, '%')) 
              OR LOWER(t.destination.name) LIKE LOWER(CONCAT('%', :keyword, '%'))
           """)
    List<Trip> searchTrips(@Param("keyword") String keyword);

    // 🏆 Featured trips (homepage section)
    List<Trip> findByFeaturedTrueOrderByCreatedAtDesc();

    // 🆕 For Admin & Public Feed (compatibility)
    List<Trip> findByApprovedTrueOrderByIdDesc();
}
