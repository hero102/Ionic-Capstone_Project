package com.aurionpro;

import java.util.Set;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.aurionpro.entity.Role;
import com.aurionpro.entity.User;
import com.aurionpro.repository.UserRepository;

@SpringBootApplication
public class TripQuestApplication {
    public static void main(String[] args) {
        SpringApplication.run(TripQuestApplication.class, args);
    }

    // create an admin user on startup if absent
    @Bean
    CommandLineRunner init(UserRepository userRepository,PasswordEncoder passwordEncoder) {
        return args -> {
            if (userRepository.findByEmail("admin@trip.com").isEmpty()) {
                User admin = new User();
                admin.setName("Admin");
                admin.setEmail("admin@trip.com");
                admin.setPassword(passwordEncoder.encode("admin123")); 
                admin.setRoles(Set.of(Role.ROLE_ADMIN, Role.ROLE_USER));
                userRepository.save(admin);
                System.out.println("Created default admin: admin@trip.com / admin123");
            }
        };
    }
}
