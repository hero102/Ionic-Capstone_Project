package com.aurionpro.config;

import com.aurionpro.service.UserService;
import com.aurionpro.util.JwtUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

@Configuration
public class SecurityConfig {

    private final JwtUtils jwtUtils;
    private final UserService userService;

    public SecurityConfig(JwtUtils jwtUtils, UserService userService) {
        this.jwtUtils = jwtUtils;
        this.userService = userService;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        JwtAuthenticationFilter jwtAuthFilter = new JwtAuthenticationFilter(jwtUtils, userService);

        http
            // 🚫 Disable CSRF for REST APIs
            .csrf(csrf -> csrf.disable())

            // 🌍 Enable CORS
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))

            // 🔐 Stateless JWT authentication
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))

            // ✅ Authorization Rules
            .authorizeHttpRequests(auth -> auth

                // 🔓 Public Endpoints
                .requestMatchers(
                    "/api/auth/**",          // Login / Register
                    "/api/trips/feed",       // Public trip feed
                    "/api/destinations/**",  // Public read access to destinations
                    "/uploads/**",           // Uploaded images
                    "/error"
                ).permitAll()

                // 🌐 Maintenance mode — everyone can GET status
                .requestMatchers("/api/settings/maintenance").permitAll()

                // 🧑‍💼 Only admin can toggle maintenance mode (POST)
                .requestMatchers("/api/settings/maintenance/**").hasRole("ADMIN")

                // 🧑‍💼 Admin-only management routes
                .requestMatchers("/api/trips/admin/**").hasRole("ADMIN")
                .requestMatchers("/api/admin/**").hasRole("ADMIN")

                // 🔒 All other endpoints require valid JWT
                .anyRequest().authenticated()
            )

            // 🔄 Add JWT Authentication Filter
            .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    // 🌍 Allow Ionic / Angular frontend access (CORS)
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(List.of(
                "http://localhost:8100", // Ionic
                "http://localhost:4200"  // Angular dev
        ));
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        config.setAllowedHeaders(List.of("Authorization", "Content-Type", "X-Requested-With", "Accept"));
        config.setAllowCredentials(true);
        config.setExposedHeaders(List.of("Authorization"));

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }

    // 🔑 Password encoder for hashing passwords
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    // 🔑 Authentication manager for AuthService (login)
    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }
}
